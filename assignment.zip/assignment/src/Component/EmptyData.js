import React from 'react'

export default function EmptyData(props) {
    return (
        <div>
            <p>{props.value}</p>
        </div>
    )
}
