import React from 'react'

export default function DataRow(props) {
        return (
                <label className={props.data}>{props.value}<br/></label>
        )
    }
